<?php

$gerichte = [
    [
        "name" => "Rindfleisch mit Bambus, Kaiserschoten und rotem Paprika, dazu Mie Nudeln",
        "preis_intern" => 3.50,
        "preis_extern" => 6.20,
        "bild" => "rindfleisch_mie.jpg"
    ],
    [
        "name" => "Spinatrissotto mit kleinen Samostateigecken und gemischter Salat",
        "preis_intern" => 2.90,
        "preis_extern" => 5.30,
        "bild" => "spinatrissotto.jpg"
    ],
    [
        "name" => "Hähnchenbrust mit Kräutersoße und Reis",
        "preis_intern" => 3.20,
        "preis_extern" => 5.80,
        "bild" => "haehnchen_kraeuter.jpg"
    ],
    [
        "name" => "Vegetarische Lasagne ",
        "preis_intern" => 3.00,
        "preis_extern" => 5.50,
        "bild" => "lasagne_vegi.jpg"
    ]
];