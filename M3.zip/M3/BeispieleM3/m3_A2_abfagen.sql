select count(*) from emensawerbeseite.gericht;

select count(*) from emensawerbeseite.allergen;

select count(*) from emensawerbeseite.gericht_hat_kategorie;

select count(*) from emensawerbeseite.gericht_hat_allergen;

select count(*) from emensawerbeseite.kategorie;
